Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$installer = Join-Path $PSScriptRoot 'Install-CursorHotfix.ps1'
$logDirectory = Join-Path $env:LOCALAPPDATA 'KB5120998-CursorHotfix\Logs'
$installLog = Join-Path $logDirectory 'install.log'

try {
    $output = & $installer *>&1
    New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null
    $output | Out-File -LiteralPath $installLog -Encoding UTF8 -Append
    exit 0
}
catch {
    New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null
    $_ | Out-String | Out-File -LiteralPath $installLog -Encoding UTF8 -Append

    Add-Type -AssemblyName System.Windows.Forms
    [void][System.Windows.Forms.MessageBox]::Show(
        "Nie udalo sie zastosowac poprawki kursora.`r`n`r`nTen komputer moze miec inna wersje Windows. Popros o pomoc osobe, od ktorej otrzymalas ten plik.",
        'Naprawa kursora',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )
    exit 1
}

