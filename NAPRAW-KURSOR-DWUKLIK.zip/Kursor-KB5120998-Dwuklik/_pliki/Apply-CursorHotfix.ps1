[CmdletBinding()]
param(
    [switch]$Force,
    [switch]$Startup,
    [switch]$DiagnosticOnly,
    [switch]$RestoreWindowsLoader
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$HotfixVersion = '1.0.0'
$TargetKb = 'KB5120998'
$LogDirectory = Join-Path $env:LOCALAPPDATA 'KB5120998-CursorHotfix\Logs'
$LogFile = Join-Path $LogDirectory 'hotfix.log'

function Write-HotfixLog {
    param([string]$Message)

    if (-not (Test-Path -LiteralPath $LogDirectory)) {
        New-Item -ItemType Directory -Path $LogDirectory -Force | Out-Null
    }

    $line = '{0} {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'), $Message
    Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
}

function Get-HotfixEnvironment {
    $currentVersion = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
    $installLanguageHex = [string](Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Nls\Language').InstallLanguage
    $installLanguageName = 'unknown'
    $isEnglishInstall = $false

    try {
        $lcid = [Convert]::ToInt32($installLanguageHex, 16)
        $installCulture = [Globalization.CultureInfo]::GetCultureInfo($lcid)
        $installLanguageName = $installCulture.Name
        $isEnglishInstall = $installCulture.TwoLetterISOLanguageName -eq 'en'
    }
    catch {
        # An unknown install language is treated conservatively as non-English.
    }

    $build = [int]$currentVersion.CurrentBuild
    $ubr = [int]$currentVersion.UBR
    $displayVersion = [string]$currentVersion.DisplayVersion
    $isTargetBuild = ($displayVersion -in @('24H2', '25H2')) -and
        ($build -in @(26100, 26200)) -and
        ($ubr -eq 9278)

    $kbInstalled = [bool](Get-HotFix -Id $TargetKb -ErrorAction SilentlyContinue)

    [pscustomobject]@{
        HotfixVersion       = $HotfixVersion
        DisplayVersion      = $displayVersion
        Build               = $build
        UBR                 = $ubr
        FullBuild           = '{0}.{1}' -f $build, $ubr
        InstallLanguage     = $installLanguageName
        CurrentUiCulture    = (Get-UICulture).Name
        IsEnglishInstall    = $isEnglishInstall
        TargetKbInstalled   = $kbInstalled
        IsTargetBuild       = $isTargetBuild
        Eligible            = $isTargetBuild -and (-not $isEnglishInstall)
        LogFile             = $LogFile
    }
}

function Initialize-CursorNativeApi {
    if ('KB5120998CursorHotfix.NativeMethods' -as [type]) {
        return
    }

    $nativeCode = @'
using System;
using System.Runtime.InteropServices;

namespace KB5120998CursorHotfix
{
    public static class NativeMethods
    {
        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern IntPtr LoadCursorFromFileW(string fileName);

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetSystemCursor(IntPtr hcur, uint id);

        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SystemParametersInfoW(uint action, uint parameter, IntPtr data, uint flags);
    }
}
'@

    Add-Type -TypeDefinition $nativeCode
}

function Restore-WindowsCursorLoader {
    Initialize-CursorNativeApi
    $spiSetCursors = [uint32]0x0057
    $ok = [KB5120998CursorHotfix.NativeMethods]::SystemParametersInfoW(
        $spiSetCursors,
        0,
        [IntPtr]::Zero,
        0
    )

    if (-not $ok) {
        $errorCode = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
        throw "SystemParametersInfoW(SPI_SETCURSORS) failed with Win32 error $errorCode."
    }

    Write-HotfixLog 'The standard Windows cursor loader was requested.'
}

function Set-RegisteredSystemCursors {
    Initialize-CursorNativeApi

    # Registry value -> Win32 OCR_* identifier.
    $cursorIds = [ordered]@{
        Arrow       = [uint32]32512
        AppStarting = [uint32]32650
        Wait        = [uint32]32514
        Hand        = [uint32]32649
        Help        = [uint32]32651
        No          = [uint32]32648
        NWPen       = [uint32]32631
        SizeAll     = [uint32]32646
        SizeNESW    = [uint32]32643
        SizeNS      = [uint32]32645
        SizeNWSE    = [uint32]32642
        SizeWE      = [uint32]32644
        UpArrow     = [uint32]32516
        Pin         = [uint32]32671
        Person      = [uint32]32672
    }

    $cursorSettings = Get-ItemProperty 'HKCU:\Control Panel\Cursors'
    $results = foreach ($cursorName in $cursorIds.Keys) {
        $property = $cursorSettings.PSObject.Properties[$cursorName]
        $cursorPath = if ($null -eq $property) { '' } else { [string]$property.Value }
        $cursorPath = [Environment]::ExpandEnvironmentVariables($cursorPath)

        if ([string]::IsNullOrWhiteSpace($cursorPath)) {
            [pscustomobject]@{
                Cursor = $cursorName
                Status = 'SkippedDefault'
                Path = ''
                Error = 0
            }
            continue
        }

        if (-not (Test-Path -LiteralPath $cursorPath -PathType Leaf)) {
            [pscustomobject]@{
                Cursor = $cursorName
                Status = 'MissingFile'
                Path = $cursorPath
                Error = 2
            }
            continue
        }

        $handle = [KB5120998CursorHotfix.NativeMethods]::LoadCursorFromFileW($cursorPath)
        if ($handle -eq [IntPtr]::Zero) {
            [pscustomobject]@{
                Cursor = $cursorName
                Status = 'LoadFailed'
                Path = $cursorPath
                Error = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
            }
            continue
        }

        # SetSystemCursor copies the cursor and destroys the supplied handle.
        $applied = [KB5120998CursorHotfix.NativeMethods]::SetSystemCursor(
            $handle,
            [uint32]$cursorIds[$cursorName]
        )

        [pscustomobject]@{
            Cursor = $cursorName
            Status = if ($applied) { 'Applied' } else { 'SetFailed' }
            Path = $cursorPath
            Error = if ($applied) { 0 } else { [Runtime.InteropServices.Marshal]::GetLastWin32Error() }
        }
    }

    return $results
}

$environment = Get-HotfixEnvironment

if ($DiagnosticOnly) {
    $environment
    return
}

if ($RestoreWindowsLoader) {
    Restore-WindowsCursorLoader
    Write-Output 'Windows cursor loader restored for the current session.'
    return
}

Write-HotfixLog (
    'Start v{0}; Windows {1} build {2}; install language {3}; eligible={4}; force={5}; startup={6}' -f
    $HotfixVersion,
    $environment.DisplayVersion,
    $environment.FullBuild,
    $environment.InstallLanguage,
    $environment.Eligible,
    $Force.IsPresent,
    $Startup.IsPresent
)

if ((-not $environment.Eligible) -and (-not $Force)) {
    Write-HotfixLog 'No action: this is not the explicitly supported affected build/language combination.'
    Write-Output 'No action: the installed Windows build/language is outside the targeted KB5120998 case.'
    $environment
    return
}

if ($Startup) {
    # Explorer and personalization finish loading after sign-in. Applying later
    # prevents the defective localized loader from overwriting the workaround.
    Start-Sleep -Seconds 7
}

$results = @(Set-RegisteredSystemCursors)
$appliedCount = @($results | Where-Object Status -eq 'Applied').Count
$failedCount = @($results | Where-Object Status -in @('MissingFile', 'LoadFailed', 'SetFailed')).Count

foreach ($result in $results) {
    Write-HotfixLog ('Cursor {0}: {1}; error={2}; path={3}' -f $result.Cursor, $result.Status, $result.Error, $result.Path)
}
Write-HotfixLog ('Complete: applied={0}; failed={1}' -f $appliedCount, $failedCount)

if ($failedCount -gt 0) {
    Write-Warning "$failedCount cursor state(s) could not be applied. See $LogFile"
}

Write-Output ("KB5120998 cursor workaround applied: {0} state(s), {1} failure(s)." -f $appliedCount, $failedCount)
$results

