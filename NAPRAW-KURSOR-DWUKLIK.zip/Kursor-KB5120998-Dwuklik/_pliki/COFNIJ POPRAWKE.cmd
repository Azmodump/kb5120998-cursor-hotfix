@echo off
"%~dp0KB5120998CursorHotfix.exe" --uninstall
exit /b %errorlevel%
