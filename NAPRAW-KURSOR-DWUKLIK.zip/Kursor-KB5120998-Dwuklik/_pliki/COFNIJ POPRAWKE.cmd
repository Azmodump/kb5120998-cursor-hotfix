@echo off
powershell.exe -NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0Uninstall-CursorHotfix.ps1" >nul 2>&1
exit /b %errorlevel%

