[CmdletBinding()]
param([switch]$Force)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$sourceScript = Join-Path $PSScriptRoot 'Apply-CursorHotfix.ps1'
if (-not (Test-Path -LiteralPath $sourceScript -PathType Leaf)) {
    throw "Missing file: $sourceScript"
}

$diagnostic = & $sourceScript -DiagnosticOnly
if ((-not $diagnostic.Eligible) -and (-not $Force)) {
    throw ('Nie wykryto obslugiwanego przypadku. Wymagany jest Windows 11 24H2/25H2, ' +
        'build 26100.9278 lub 26200.9278, z nieangielskim jezykiem instalacji.')
}

$installDirectory = Join-Path $env:LOCALAPPDATA 'KB5120998-CursorHotfix'
$installedScript = Join-Path $installDirectory 'Apply-CursorHotfix.ps1'
$startupDirectory = [Environment]::GetFolderPath('Startup')
$shortcutPath = Join-Path $startupDirectory 'KB5120998 Cursor Hotfix.lnk'
$powerShellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

New-Item -ItemType Directory -Path $installDirectory -Force | Out-Null
Copy-Item -LiteralPath $sourceScript -Destination $installedScript -Force

$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $powerShellExe
$shortcut.Arguments = '-NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "{0}" -Startup' -f $installedScript
$shortcut.WorkingDirectory = $installDirectory
$shortcut.Description = 'Session workaround for the KB5120998 cursor regression'
$shortcut.Save()

Write-Output "Installed per-user hotfix in: $installDirectory"
Write-Output "Installed startup shortcut: $shortcutPath"

if ($Force) {
    & $installedScript -Force
}
else {
    & $installedScript
}

Write-Output 'Installation complete. Administrator rights were not required.'
