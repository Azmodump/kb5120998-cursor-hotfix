[CmdletBinding()]
param([switch]$Force)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$sourceScript = Join-Path $PSScriptRoot 'Apply-CursorHotfix.ps1'
if (-not (Test-Path -LiteralPath $sourceScript -PathType Leaf)) {
    throw "Missing file: $sourceScript"
}

$diagnostic = & $sourceScript -DiagnosticOnly
if ((-not $diagnostic.Eligible) -and (-not $Force)) {
    throw ('Nie wykryto obslugiwanego przypadku. Wymagany jest Windows 11 24H2/25H2, ' +
        'build 26100.9278 lub 26200.9278, z nieangielskim jezykiem instalacji.')
}

$installDirectory = Join-Path $env:LOCALAPPDATA 'KB5120998-CursorHotfix'
$installedScript = Join-Path $installDirectory 'Apply-CursorHotfix.ps1'
$startupDirectory = [Environment]::GetFolderPath('Startup')
$shortcutPath = Join-Path $startupDirectory 'KB5120998 Cursor Hotfix.lnk'
$powerShellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$runValueName = 'KB5120998CursorHotfix'

New-Item -ItemType Directory -Path $installDirectory -Force | Out-Null
Copy-Item -LiteralPath $sourceScript -Destination $installedScript -Force

$runCommand = '"{0}" -NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "{1}" -Startup' -f $powerShellExe, $installedScript
New-Item -Path $runKey -Force | Out-Null
New-ItemProperty -Path $runKey -Name $runValueName -PropertyType String -Value $runCommand -Force | Out-Null

# Version 1.0 used a Startup-folder shortcut. Remove it when upgrading because
# the per-user Run entry is more reliable on systems with customized policies.
if (Test-Path -LiteralPath $shortcutPath) {
    Remove-Item -LiteralPath $shortcutPath -Force
}

Write-Output "Installed per-user hotfix in: $installDirectory"
Write-Output "Installed per-user startup entry: $runValueName"

if ($Force) {
    & $installedScript -Force
}
else {
    & $installedScript
}

Write-Output 'Installation complete. Administrator rights were not required.'
