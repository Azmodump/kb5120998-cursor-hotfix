@echo off
"%~dp0_pliki\KB5120998CursorHotfix.exe" --install
exit /b %errorlevel%
